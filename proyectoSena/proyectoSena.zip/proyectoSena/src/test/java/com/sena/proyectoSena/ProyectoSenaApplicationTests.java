package com.sena.proyectoSena;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoSenaApplicationTests {

	@Test
	void contextLoads() {
	}

}
